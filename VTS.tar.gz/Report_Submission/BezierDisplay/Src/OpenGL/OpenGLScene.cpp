//
//  OpenGLScene.cpp
//  BezierDisplay
//
//  Created by Papoj Thamjaroenporn on 11/9/12.
//  Copyright (c) 2012 Papoj Thamjaroenporn. All rights reserved.
//

#include "OpenGLScene.h"
#include "OpenGLDisplayController.h"

#include "PolyBezierScene.h"
#include "CurveDef.h"


////////////////////////////////////////////////////////////////////////////////////////////////////
// Rendering state

OpenGLDisplayController g_display_controller( 800, 600 );

SceneObjectData g_scene_object_data;
SceneControllerData g_scene_controller_data( 1.2 );
SceneMiscData g_scene_misc_data( renderingutils::Color( 1.0, 1.0, 1.0 ) );


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// OpenGL rendering and UI functions
//
////////////////////////////////////////////////////////////////////////////////////////////////////

//Called when the window size is changed.
void reshape (int w, int h)
{
	g_display_controller.reshape( w, h );
	
	assert( renderingutils::checkGLErrors() );
}

void setOrthographicProjection()
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	
	gluOrtho2D(0, g_display_controller.getWindowWidth(), 0, g_display_controller.getWindowHeight());
	
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	
	assert( renderingutils::checkGLErrors() );
}

void drawHUD()
{

}

void display()
{
	glClear( GL_COLOR_BUFFER_BIT );
	
	glMatrixMode( GL_MODELVIEW );
	
	if (g_scene_object_data.m_drawGrid)
		drawGrid(*(g_scene_object_data.g_gridMaxX), *(g_scene_object_data.g_gridMaxY), *(g_scene_object_data.g_gridSize));
	
	g_scene_object_data.g_bezier_renderer->renderScene();
	
	//drawHUD();
	
	glutSwapBuffers();
	
	assert( renderingutils::checkGLErrors() );
	
}

void findSceneBoundary(scalar & min_x, scalar & min_y, scalar & max_x, scalar & max_y)
{

	const PolyBezierScene & curveScene = g_scene_object_data.g_bezier_renderer->getScene();
	const curvedef::VectorPolyCurve & curves = curveScene.getCurves();
	curvedef::VectorPolyCurve::const_iterator curveIt;
	
	// Compute the bounds of the scene	
	max_x = -std::numeric_limits<scalar>::infinity();
	min_x =  std::numeric_limits<scalar>::infinity();
	max_y = -std::numeric_limits<scalar>::infinity();
	min_y =  std::numeric_limits<scalar>::infinity();
	
	Vector12s point;
	for( curveIt = curves.begin(); curveIt != curves.end(); ++curveIt )
	{
		const VectorX2s & controlPoints = curveIt->getControlPoints();
		
		VectorX2s_const_iterator controlPointsIt ( &controlPoints );
		VectorX2s_const_iterator end ( &controlPoints, controlPoints.rows() );

		while ( controlPointsIt != end) {
			point = *controlPointsIt;

			if (point(0) < min_x) min_x = point(0);
			if (point(0) > max_x) max_x = point(0);
			if (point(1) < min_y) min_y = point(1);
			if (point(1) > max_y) max_y = point(1);
			
			++controlPointsIt;
		}
		
	}

}

void centerCamera()
{
	scalar min_x, min_y, max_x, max_y;
	findSceneBoundary( min_x, min_y, max_x, max_y );
	
	// Find the center of the bound
	scalar cx = 0.5*(min_x + max_x);
	scalar cy = 0.5*(min_y + max_y);
	
	// Set the zoom value so all control points are in view
	scalar radius_x = 0.5*(max_x - min_x);
	if (radius_x == 0.0) radius_x = 1.0;
	scalar radius_y = 0.5*(max_y - min_y);
	if (radius_y == 0.0) radius_y = 1.0;
	scalar ratio = ((scalar)g_display_controller.getWindowHeight()) /
					((scalar)g_display_controller.getWindowWidth());
	
	centerCamera( cx, cy, g_scene_controller_data.m_recenterScale*std::max(ratio*radius_x, radius_y) );

}

void centerCamera( scalar cx, scalar cy )
{
	scalar min_x, min_y, max_x, max_y;
	findSceneBoundary( min_x, min_y, max_x, max_y );
	
	// Set the zoom value so all control points are in view
	scalar radius_x = std::max( std::abs(min_x), std::abs(max_x) );
	if (radius_x == 0.0) radius_x = 1.0;
	scalar radius_y = std::max( std::abs(min_y), std::abs(max_y) );
	if (radius_y == 0.0) radius_y = 1.0;
	scalar ratio = ((scalar)g_display_controller.getWindowHeight()) /
					((scalar)g_display_controller.getWindowWidth());
	
	centerCamera( cx, cy, g_scene_controller_data.m_recenterScale*std::max(ratio*radius_x, radius_y) );
}

void centerCamera( scalar cx, scalar cy, scalar scale )
{
	g_display_controller.setCenterX( cx );
	g_display_controller.setCenterY( cy );
	g_display_controller.setScaleFactor( scale );
}

void keyboard( unsigned char key, int x, int y )
{
	g_display_controller.keyboard( key, x, y );
	g_scene_object_data.g_bezier_renderer->keyboard( key, x, y );
	
	// GLOBAL KEYS //
	// Quit the program
	if( key == 'q' )
	{
		exit(0);
	}
	
	// Re-center the scene with minimal boundary
	else if( key == 'c' )
	{
		centerCamera();
		g_display_controller.reshape( g_display_controller.getWindowWidth(),
									  g_display_controller.getWindowHeight() );
		glutPostRedisplay();
	}
	
	// Re-center the scene with origin at center
	else if( key == 'C' )
	{
		centerCamera(0.0, 0.0);
		g_display_controller.reshape( g_display_controller.getWindowWidth(),
									  g_display_controller.getWindowHeight() );
		glutPostRedisplay();
	}
	
	else if( key == ']')
	{
		*(g_scene_object_data.g_gridMaxX) += 1;
		*(g_scene_object_data.g_gridMaxY) += 1;
	}
	else if( key == '[')
	{
		*(g_scene_object_data.g_gridMaxX) -= 1;
		*(g_scene_object_data.g_gridMaxY) -= 1;
		
		if ( *(g_scene_object_data.g_gridMaxX) < 0) *(g_scene_object_data.g_gridMaxX) = 0;
		if ( *(g_scene_object_data.g_gridMaxY) < 0) *(g_scene_object_data.g_gridMaxY) = 0;
	}
	
	if ( key == 'G')
	{
		g_scene_object_data.m_drawGrid = !g_scene_object_data.m_drawGrid;
	}
	
	assert( renderingutils::checkGLErrors() );
}

void special( int key, int x, int y )
{
	g_display_controller.special( key, x, y );
	
	assert( renderingutils::checkGLErrors() );
}

void mouse( int button, int state, int x, int y )
{
	// Detect if SHIFT key is being held down or not during the mouse callback
	int mymod = glutGetModifiers();
	if( g_scene_controller_data.m_activeshift && ( mymod != GLUT_ACTIVE_SHIFT ))
	{
		g_scene_controller_data.m_activeshift = false;
	}
	else if( !g_scene_controller_data.m_activeshift && ( mymod == GLUT_ACTIVE_SHIFT ))
	{
		g_scene_controller_data.m_activeshift = true;
	}

	if( !g_scene_controller_data.m_right_drag && button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
	{
		g_scene_controller_data.m_left_drag = true;
		g_scene_controller_data.m_last_x = x;
		g_scene_controller_data.m_last_y = y;
	}
	if( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
	{
		g_scene_controller_data.m_left_drag = false;
	}

	if( !g_scene_controller_data.m_left_drag && button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
	{
		g_scene_controller_data.m_right_drag = true;
		g_scene_controller_data.m_last_x = x;
		g_scene_controller_data.m_last_y = y;
	}
	if( button == GLUT_RIGHT_BUTTON && state == GLUT_UP )
	{
		g_scene_controller_data.m_right_drag = false;
	}
	
	if ( g_scene_controller_data.m_activeshift )
	{
		// g_display_controller.mouse( button, state, x, y );
	}
	else
	{
		g_scene_object_data.g_bezier_renderer->mouse(button, state, x, y, g_scene_controller_data);
	}

	
	
	assert( renderingutils::checkGLErrors() );
}

void motion( int x, int y )
{
	// If SHIFT is held, interpret motion for camera adjustment
	if ( g_scene_controller_data.m_activeshift ) {
		g_display_controller.motion( x, y, g_scene_controller_data);
	}
	// If SHIFT is not held, interpret mouse movement for selection and scene object manipulation
	else {
		g_scene_object_data.g_bezier_renderer->motion( x, y, g_scene_controller_data);
	}
	
	assert( renderingutils::checkGLErrors() );
}

void idle()
{
	glutPostRedisplay();
	
	assert( renderingutils::checkGLErrors() );
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// initializeOpenGLandGLUT and runOpenGL methods
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void initializeOpenGLandGLUT ( int argc, char** argv ) {

	// Set camera at center of the scene
	centerCamera( 0.0, 0.0, 1.0 );

	// Initialize GLUT
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );					// Buffer and color
	glutInitWindowSize( g_display_controller.getWindowWidth(),
						g_display_controller.getWindowHeight() );
	glutCreateWindow("Bezier Curve Display");
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(special);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutIdleFunc(idle);
  
	// Initialize OpenGL
	reshape(g_display_controller.getWindowWidth(),g_display_controller.getWindowHeight());
	glClearColor(	g_scene_misc_data.m_bgColor.r,
					g_scene_misc_data.m_bgColor.g,
					g_scene_misc_data.m_bgColor.b,
					1.0);
  
	assert( renderingutils::checkGLErrors() );
	
}

void setPolyBezierSceneRenderer( PolyBezierSceneRenderer * sceneRenderer )
{
	g_scene_object_data.g_bezier_renderer = sceneRenderer;
}

void runOpenGL ()
{
	glutMainLoop ();
}


void initializeGrid( int & gridMaxX, int & gridMaxY, scalar & gridSize)
{
	g_scene_object_data.g_gridMaxX = &gridMaxX;
	g_scene_object_data.g_gridMaxY = &gridMaxY;
	g_scene_object_data.g_gridSize = &gridSize;
}

void drawGrid(int maxX, int maxY, double gridSize) {

	glPushMatrix();

	glEnable(GL_LINE_SMOOTH);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glBegin(GL_LINES);
	
	// Grid
	{
		glColor4f( 0.7, 0.7, 0.7, 0.5 );
		for ( double x = - maxX; x <= maxX; x += gridSize ) {
			glVertex2d( x, maxY );
			glVertex2d( x, -maxY );
		}
		
		for ( double y = - maxY; y <= maxY; y += gridSize ) {
			glVertex2d( -maxX, y );
			glVertex2d( maxX, y );
		}
	}
	
	glEnd();
	
	glLineWidth( 1.0 );
	
	glEnable(GL_LINE_SMOOTH);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glBegin(GL_LINES);
	
	// Axes
	{
		glColor4f( 0.0, 0.0, 0.0, 0.5 );
		
		glVertex2d( 0, maxY );
		glVertex2d( 0, -maxY );

		glVertex2d( -maxX, 0 );
		glVertex2d( maxX, 0 );
	}
	
	glEnd();
	glLineWidth( 1.0 );
	
	glPopMatrix();
}